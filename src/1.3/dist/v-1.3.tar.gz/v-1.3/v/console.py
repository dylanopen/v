def pt(*text, end="", join="", flush=True):
	print(*text, end=end, sep=join, flush=flush)